from django.apps import AppConfig


class RmadanConfig(AppConfig):
    name = 'rmadan'
